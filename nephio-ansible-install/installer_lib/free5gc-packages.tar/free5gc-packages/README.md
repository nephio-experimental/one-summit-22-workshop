# free5gc-packages
Kpt packages for free5gc operators and network functions.
