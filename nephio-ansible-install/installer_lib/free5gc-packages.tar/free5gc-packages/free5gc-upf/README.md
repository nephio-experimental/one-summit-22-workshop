# free5gc-upf

## Description
free5gc UPF package for creating UPF deployments that will be made by the Nephio free5gc edge operator

