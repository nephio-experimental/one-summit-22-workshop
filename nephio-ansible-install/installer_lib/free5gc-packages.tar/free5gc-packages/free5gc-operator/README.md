# free5gc-operator

## Description
Operator package for free5gc Nephio integration

